'use client';

import React, { useEffect, useState } from 'react';
import { Header } from '@/components/listing/Header';
import { StickySubNav } from '@/components/listing/StickySubNav';
import { TitleSection } from '@/components/listing/TitleSection';
import { HeroPhotoGrid } from '@/components/listing/HeroPhotoGrid';
import { HostSection } from '@/components/listing/HostSection';
import { Highlights } from '@/components/listing/Highlights';
import { DescriptionSection } from '@/components/listing/DescriptionSection';
import { WhereYouSleep } from '@/components/listing/WhereYouSleep';
import { AmenitiesSection } from '@/components/listing/AmenitiesSection';
import { AvailabilityCalendar } from '@/components/listing/AvailabilityCalendar';
import { BookingWidget } from '@/components/listing/BookingWidget';
import { ReviewsSection } from '@/components/listing/ReviewsSection';
import { MapSection } from '@/components/listing/MapSection';
import { MeetYourHost } from '@/components/listing/MeetYourHost';
import { ThingsToKnow } from '@/components/listing/ThingsToKnow';
import { MoreStaysNearby } from '@/components/listing/MoreStaysNearby';
import { Footer } from '@/components/listing/Footer';
import { PhotoTour } from '@/components/overlays/PhotoTour';
import { Lightbox } from '@/components/overlays/Lightbox';

interface Room {
  id: string;
  name: string;
  detail: string;
  photoUrl: string;
}

interface CoHost {
  id: string;
  name: string;
  avatarUrl?: string | null;
  initial?: string | null;
}

interface NearbyListing {
  id: string;
  title: string;
  photoUrl: string;
  pricePerNight: number;
  rating: number;
}

interface ListingData {
  id: string;
  title: string;
  description: string;
  propertyType: string;
  location: string;
  rating: number;
  reviewCount: number;
  pricePerNight: number;
  totalStayPrice: number;
  stayNights: number;
  cleaningFee: number;
  serviceFee: number;
  maxGuests: number;
  bedrooms: number;
  beds: number;
  bathrooms: number;
  isSuperhost: boolean;
  isGuestFavourite: boolean;
  hostName: string;
  hostAvatar: string;
  hostJoined: string;
  hostReviewsCount: number;
  hostRating: number;
  hostYears: number;
  hostBorn: string;
  hostSchool: string;
  hostResponseRate: string;
  hostResponseTime: string;
  lat: number;
  lng: number;
  photos: Array<{
    id: string;
    url: string;
    alt: string;
    category: string;
    caption?: string | null;
  }>;
  rooms: Room[];
  amenities: Array<{
    id: string;
    name: string;
    iconName: string;
    category?: string;
  }>;
  reviews: Array<{
    id: string;
    authorName: string;
    authorAvatar?: string | null;
    authorInitial?: string | null;
    authorTenure: string;
    date: string;
    rating: number;
    comment: string;
  }>;
  coHosts: CoHost[];
  nearbyListings: NearbyListing[];
}

export default function ListingPage({ params }: { params: { id: string } }) {
  const [listing, setListing] = useState<ListingData | null>(null);
  const [loading, setLoading] = useState(true);

  // Shared Date Range State (Default: Oct 18, 2026 - Oct 23, 2026)
  const [checkInDate, setCheckInDate] = useState<Date | null>(new Date(2026, 9, 18));
  const [checkOutDate, setCheckOutDate] = useState<Date | null>(new Date(2026, 9, 23));

  // Overlay States
  const [isPhotoTourOpen, setIsPhotoTourOpen] = useState(false);
  const [isLightboxOpen, setIsLightboxOpen] = useState(false);
  const [lightboxIndex, setLightboxIndex] = useState(0);

  useEffect(() => {
    async function fetchListing() {
      try {
        const id = params?.id || 'listing-1';
        const res = await fetch(`/api/listing/${id}`);
        if (res.ok) {
          const data = await res.json();
          setListing(data);
        }
      } catch (err) {
        console.error('Error fetching listing:', err);
      } finally {
        setLoading(false);
      }
    }
    fetchListing();
  }, [params]);

  if (loading || !listing) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-white text-airbnb-charcoal font-medium">
        <div className="flex flex-col items-center gap-3">
          <div className="h-8 w-8 animate-spin rounded-full border-4 border-airbnb-rausch border-t-transparent" />
          <p className="text-sm">Loading listing...</p>
        </div>
      </div>
    );
  }

  const handleOpenPhotoTour = (startIndex: number = 0) => {
    setIsPhotoTourOpen(true);
  };

  const handleOpenLightbox = (index: number) => {
    setLightboxIndex(index);
    setIsLightboxOpen(true);
  };

  const handleDatesChange = (checkIn: Date | null, checkOut: Date | null) => {
    setCheckInDate(checkIn);
    setCheckOutDate(checkOut);
  };

  const priceText = `₹${listing.totalStayPrice.toLocaleString('en-IN')} for ${listing.stayNights} nights`;

  return (
    <div className="min-h-screen flex flex-col bg-white">
      {/* Top Header */}
      <Header />

      {/* Sticky Sub Nav (Appears on scroll past hero photos) */}
      <StickySubNav
        priceText={priceText}
        rating={listing.rating}
        reviewCount={listing.reviewCount}
      />

      {/* Main Container */}
      <main className="mx-auto w-full max-w-[1280px] px-10 py-6 flex-1 space-y-6">
        {/* Title Section */}
        <TitleSection
          title={listing.title}
          rating={listing.rating}
          reviewCount={listing.reviewCount}
          location={listing.location}
          isSuperhost={listing.isSuperhost}
        />

        {/* Hero 5-Photo Grid */}
        <div id="hero-photos">
          <HeroPhotoGrid
            photos={listing.photos}
            onOpenPhotoTour={handleOpenPhotoTour}
          />
        </div>

        {/* 2-Column Content Layout */}
        <div className="grid grid-cols-12 gap-16 pt-4">
          {/* Left Column */}
          <div className="col-span-7 space-y-6">
            <HostSection
              propertyType={listing.propertyType}
              maxGuests={listing.maxGuests}
              bedrooms={listing.bedrooms}
              beds={listing.beds}
              bathrooms={listing.bathrooms}
              hostName={listing.hostName}
              hostAvatar={listing.hostAvatar}
              isSuperhost={listing.isSuperhost}
            />

            {/* Guest Favourite Small Banner */}
            <div className="rounded-2xl border border-airbnb-border p-6 flex items-center justify-between shadow-sm">
              <div className="flex items-center gap-3">
                <div className="flex items-center gap-1 font-bold text-airbnb-charcoal">
                  <span>🏆</span>
                  <span>Guest favourite</span>
                </div>
                <span className="text-sm text-airbnb-muted">
                  One of the most loved homes on Airbnb, according to guests
                </span>
              </div>
              <div className="flex items-center gap-4 border-l border-airbnb-border pl-6 text-right">
                <div>
                  <div className="text-lg font-extrabold text-airbnb-charcoal">
                    {listing.rating.toFixed(2)} ★★★★★
                  </div>
                  <div className="text-xs text-airbnb-muted">
                    {listing.reviewCount} Reviews
                  </div>
                </div>
              </div>
            </div>

            <Highlights />

            <DescriptionSection description={listing.description} />

            <WhereYouSleep rooms={listing.rooms} />

            <div id="amenities">
              <AmenitiesSection amenities={listing.amenities} />
            </div>

            {/* Availability Calendar Section (Positioned directly between Amenities and Reviews) */}
            <AvailabilityCalendar
              location={listing.location}
              checkInDate={checkInDate}
              checkOutDate={checkOutDate}
              onDatesChange={handleDatesChange}
            />
          </div>

          {/* Right Column (Sticky Booking Widget) */}
          <div className="col-span-5 relative">
            <BookingWidget
              pricePerNight={listing.pricePerNight}
              cleaningFee={listing.cleaningFee}
              serviceFee={listing.serviceFee}
              rating={listing.rating}
              reviewCount={listing.reviewCount}
              maxGuests={listing.maxGuests}
              checkInDate={checkInDate}
              checkOutDate={checkOutDate}
            />
          </div>
        </div>

        {/* Full-width Sections */}
        <ReviewsSection
          rating={listing.rating}
          reviewCount={listing.reviewCount}
          reviews={listing.reviews}
        />

        <MapSection
          location={listing.location}
          lat={listing.lat}
          lng={listing.lng}
        />

        <MeetYourHost
          hostName={listing.hostName}
          hostAvatar={listing.hostAvatar}
          hostJoined={listing.hostJoined}
          hostReviewsCount={listing.hostReviewsCount}
          hostRating={listing.hostRating}
          hostYears={listing.hostYears}
          hostBorn={listing.hostBorn}
          hostSchool={listing.hostSchool}
          hostResponseRate={listing.hostResponseRate}
          hostResponseTime={listing.hostResponseTime}
          coHosts={listing.coHosts}
        />

        <ThingsToKnow />

        <MoreStaysNearby listings={listing.nearbyListings} />
      </main>

      {/* Footer */}
      <Footer />

      {/* Overlays */}
      <PhotoTour
        isOpen={isPhotoTourOpen}
        onClose={() => setIsPhotoTourOpen(false)}
        photos={listing.photos}
        onSelectPhoto={handleOpenLightbox}
      />

      <Lightbox
        isOpen={isLightboxOpen}
        onClose={() => setIsLightboxOpen(false)}
        photos={listing.photos}
        currentIndex={lightboxIndex}
        onIndexChange={setLightboxIndex}
      />
    </div>
  );
}
